# UBoat-Panel
Panel for the http botnet UBoat - https://github.com/Souhardya/UBoat/
### N.B: I didn't code this panel, I just modified a few things and hosted it on my account.
